package GPL;

public class VertexIter
{
    public boolean hasNext( ) { return false; }
    public Vertex next( ) { return null; }
}