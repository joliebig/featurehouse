package GPL;

public class EdgeIter
{
    public boolean hasNext( ) { return false; }
    public EdgeIfc next( ) { return null; }
}