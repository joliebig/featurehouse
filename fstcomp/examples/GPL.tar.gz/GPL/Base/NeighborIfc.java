package GPL;

import java.util.LinkedList;

// Vertex class

 // *************************************************************************

public interface NeighborIfc
{
}
