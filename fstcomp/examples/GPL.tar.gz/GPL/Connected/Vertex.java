package GPL;

// *****************************************************************
   
public class Vertex 
{
    public int componentNumber;

    public void display( ) 
    {
        System.out.print( " comp# "+ componentNumber + " " );
        original( );
    }
}
