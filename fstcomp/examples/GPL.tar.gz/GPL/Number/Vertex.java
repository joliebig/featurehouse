package GPL;

// ***********************************************************************
  
public class Vertex 
{
    public int VertexNumber;

    public void display( ) 
    {
        System.out.print( " # "+ VertexNumber + " " );
        original( );
    }
}
