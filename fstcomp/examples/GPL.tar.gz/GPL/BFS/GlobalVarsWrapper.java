package GPL;

import java.util.LinkedList;

// Class to wrap global variables
   
public class GlobalVarsWrapper 
{
    public static LinkedList Queue =  new LinkedList();
}
