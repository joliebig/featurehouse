module Arith where
{
  eval :: Exp TypedVal -> Exp TypedVal -> Result TypedVal EvalError;
}
