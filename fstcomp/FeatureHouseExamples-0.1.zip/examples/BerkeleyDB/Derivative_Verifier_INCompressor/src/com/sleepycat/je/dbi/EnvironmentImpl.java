package com.sleepycat.je.dbi;
public class EnvironmentImpl {
  public void verifyCursors() throws DatabaseException {
    inCompressor.verifyCursors();
  }
}
