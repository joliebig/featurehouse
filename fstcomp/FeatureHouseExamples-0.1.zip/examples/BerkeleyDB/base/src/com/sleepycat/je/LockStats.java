package com.sleepycat.je;
import java.io.Serializable;
import de.ovgu.cide.jakutil.*;
/** 
 * Javadoc for this public class is generated
 * via the doc templates in the doc_src directory.
 */
public class LockStats implements Serializable {
}
