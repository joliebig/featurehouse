package com.sleepycat.je;
public class CheckpointConfig {
  private int minutes=0;
  /** 
 * Javadoc for this public method is generated via
 * the doc templates in the doc_src directory.
 */
  public void setMinutes(  int minutes){
    this.minutes=minutes;
  }
  /** 
 * Javadoc for this public method is generated via
 * the doc templates in the doc_src directory.
 */
  public int getMinutes(){
    return minutes;
  }
}
