package com.sleepycat.je;
public class CheckpointConfig {
  private int kbytes=0;
  /** 
 * Javadoc for this public method is generated via
 * the doc templates in the doc_src directory.
 */
  public void setKBytes(  int kbytes){
    this.kbytes=kbytes;
  }
  /** 
 * Javadoc for this public method is generated via
 * the doc templates in the doc_src directory.
 */
  public int getKBytes(){
    return kbytes;
  }
}
