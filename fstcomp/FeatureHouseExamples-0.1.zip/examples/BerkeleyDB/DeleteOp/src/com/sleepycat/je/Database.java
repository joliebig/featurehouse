package com.sleepycat.je;
public class Database {
  protected void hook55() throws DatabaseException {
    databaseImpl.checkIsDeleted("preload");
    original();
  }
  protected void hook56() throws DatabaseException {
    databaseImpl.checkIsDeleted("preload");
    original();
  }
  protected void hook57() throws DatabaseException {
    databaseImpl.checkIsDeleted("preload");
    original();
  }
}
