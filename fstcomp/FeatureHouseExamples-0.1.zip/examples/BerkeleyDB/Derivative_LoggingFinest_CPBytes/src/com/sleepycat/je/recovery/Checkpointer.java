package com.sleepycat.je.recovery;
public class Checkpointer {
@MethodObject static class Checkpointer_isRunnable {
    protected void hook517() throws DatabaseException {
      sb.append("size interval=").append(useBytesInterval);
      original();
    }
  }
}
