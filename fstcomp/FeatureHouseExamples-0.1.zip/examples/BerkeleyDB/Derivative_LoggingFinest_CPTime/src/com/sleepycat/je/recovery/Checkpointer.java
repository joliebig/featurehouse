package com.sleepycat.je.recovery;
public class Checkpointer {
@MethodObject static class Checkpointer_isRunnable {
    protected void hook518() throws DatabaseException {
      sb.append(" time interval=").append(useTimeInterval);
      original();
    }
  }
}
