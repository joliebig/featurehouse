/** 
 */
package com.sleepycat.je.dbi;
class StatsAccumulator {
  void verifyNode(  Node node){
  }
  protected void hook363(  IN node){
    verifyNode(node);
    original(node);
  }
  protected void hook364(  BIN node){
    verifyNode(node);
    original(node);
  }
  protected void hook365(  DIN node){
    verifyNode(node);
    original(node);
  }
  protected void hook366(  DBIN node){
    verifyNode(node);
    original(node);
  }
  protected void hook367(  DupCountLN node){
    verifyNode(node);
    original(node);
  }
}
