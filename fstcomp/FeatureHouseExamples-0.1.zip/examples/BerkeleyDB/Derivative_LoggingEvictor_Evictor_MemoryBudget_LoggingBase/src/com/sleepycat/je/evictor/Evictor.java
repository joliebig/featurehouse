package com.sleepycat.je.evictor;
public class Evictor {
@MethodObject static class Evictor_isRunnable {
    protected void hook370() throws DatabaseException {
      sb.append(" doRun=").append(doRun);
      sb.append(" JEusedBytes=").append(_this.formatter.format(currentUsage));
      original();
    }
  }
}
