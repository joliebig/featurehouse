package com.sleepycat.je.cleaner;
class FileProcessor {
@MethodObject static class FileProcessor_processFile {
    protected void hook118() throws DatabaseException, IOException {
      adjustMem+=lookAheadCacheSize;
      original();
    }
  }
}
