NewCompound1 : NewLayer1 ;

